#ifndef _MEDIA_MT9T001_H
#define _MEDIA_MT9T001_H

struct mt9t001_platform_data {
	unsigned int clk_pol:1;
	unsigned int ext_clk;
};

#endif
